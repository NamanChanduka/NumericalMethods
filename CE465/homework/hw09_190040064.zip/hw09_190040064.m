%
% -------------------
% This is a solution to the Homework no. 6 for  CE 465, Numerical Methods in Civil Engineering
% course at IIT Bombay instructed by Prof. Ravi Sinha (Spring 2020-21)
%
% in the present file we have to evaluate the eight storied industrial
% structure as given in the question and find smallest four eigenvalues
%
%
% Author: Naman Chanduka, IIT Bombay
%
%
% -------------------

clear; clc; close all; %used for clearing the workspace

tic; %used for monitoring the runtime of the program

format long; %to accurately see more decimal points

%%
%%%%%%%%  Start of User Input  %%%%%%%%%%%%%%%
k = [100; 100; 100; 80; 80; 1; 60; 60; 20; 20; 0.15; 0.2];  

K = [k(1)+k(2)+k(10), -k(2), -k(10), 0, 0, 0, 0, 0;                         %Defining stiffness matrix which is A matrix in Ax = b in this case
    -k(2), k(2)+k(3)+k(11), -k(3), 0, 0, 0, 0, -k(11);
    -k(10), -k(3), k(3)+k(4)+k(9)+k(10), -k(4), -k(9), 0, 0, 0;
    0, 0, -k(4), k(4)+k(5)+k(12), -k(5), 0, -k(12), 0;
    0, 0, -k(9), -k(5), k(5)+k(6)+k(9), -k(6), 0, 0;
    0, 0, 0, 0, -k(6), k(6)+k(7), -k(7), 0;
    0, 0, 0, -k(12), 0, -k(7), k(7)+k(8)+k(12), -k(8);
    0, -k(11), 0, 0, 0, 0, -k(8), k(8)+k(11)];

m = [1000, 1000, 1000, 800, 800, 600, 600, 600];                            %Defining the values of m1....m8

n = 8;

tol = eps*1e+04;                                                            % tolerance

NumberNeeded = 4;                                                           %no of eigenvalues to be found

%Method = 'Jacobi'
Method = 'SubSpace'
%Method = 'Matlab inbuilt'


%%
%%%% Start of Program %%%%

M = diag([m(1), m(2), m(3), m(4), m(5), m(6), m(7), m(8)]);

M_halfinverse = diag([1/sqrt(m(1)), 1/sqrt(m(2)), 1/sqrt(m(3)), 1/sqrt(m(4)), 1/sqrt(m(5)), 1/sqrt(m(6)), 1/sqrt(m(7)), 1/sqrt(m(8))]);         %Creating M^-1/2 matrix

A = M_halfinverse*K*M_halfinverse;                                          %Defining A matrix as specified in the problem statement         

switch Method
    case 'Jacobi'     

        [eigenVal, eigenVector, iterations, offList] = hw08_Jacobi(A, n, tol);                   %Calling Jacobi Function 
        
    case 'SubSpace'
        [eigenVal, eigenVector, iterations, errorList] = hw09_subspace(K, M, NumberNeeded, tol); %calling the subspace iteration method 

    case 'Matlab inbuilt'

        eigenVal = eig(A);
        
end


disp('EigenValues:');
disp(sort(eigenVal));
if strcmp(Method, 'Jacobi') || strcmp(Method,'SubSpace')
    rel = abs((eigenVal - eig(A))./eig(A));
    disp('Relative error:');
    disp(rel);
    disp('No of iterations:');
    disp(iterations);
end
    
    
toc;
%%%% End of Program %%%%

