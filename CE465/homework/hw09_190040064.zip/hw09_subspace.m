function [eigenVal, eigenVector, iteration, errors] = hw09_subspace(K, M, NumberNeeded, tol)
n = size(K, 1);
q = min(NumberNeeded*2, NumberNeeded+8);
X = rand(n, q);
iteration = 1;
errors(1) = n;                                                              %initialize random value for error 
errors(2) = n+2;  


while (errors(iteration) > tol)
    iteration = iteration + 1;
    RHS = M * X;
    for column = 1:q
        [ Xhat_next(:, column), ~, ~, ~] = hw06_gauss(K, RHS(:, column));
    end
    
    K_next = Xhat_next' * K * Xhat_next;                                          %Projection of K and M on q x q space 
    M_next = Xhat_next' * M * Xhat_next;
    
    
    [Q_next, eigVal_here] = eig(M_next \ K_next);
    eigVALUES(:, iteration) = sort(diag(eigVal_here));
    if iteration == 2 
        
    else
        errors(iteration) = max(abs((eigVALUES(:, iteration) - eigVALUES(:, iteration-1))./eigVALUES(:, iteration)));
    end

    X_next = Xhat_next * Q_next;                                            %New approximation
    X = X_next;
    
    
end

eigenVal = eigVALUES(:, iteration);
eigenVector = X_next;