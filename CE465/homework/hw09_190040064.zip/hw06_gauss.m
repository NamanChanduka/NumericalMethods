function [sol, U, pivot, det] = hw06_gauss(A, b)
pivot = [0, 0, 0,0,0,0,0,0]; %init pivot
n = size(A, 1);  % size of the input matrix
[U, pivot, det, ier] = hw06_factor(A,n,pivot);
sol = hw06_solve(U, n, b, pivot);