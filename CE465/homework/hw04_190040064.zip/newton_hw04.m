function [answer, X_double, Y_double, Y_Err] = newton_hw03(func, funcpart, x0, iterations)         %Defining Newton Function
    
polynomial = func;
if(funcpart == 'A')
    derivative = @(x) 3*x.^2 - 6*x + 3;
elseif(funcpart == 'B')
    derivative = @(x) 4*x.^3 - 9*x.^2 + 40*x + 44;
end
X_double = double.empty(iterations+1, 0);                                   %initializing array that will be required for plotting
Y_double = double.empty(iterations+1, 0);  
errorcode = -1;                                                             %initialize errorcode to find irregularities during runtime
itnum = 0;                                                                  %initialize iteration variable
answer = 0;
converge = 2.22e-14;                                                        %convergence criterion according to question
while(errorcode == -1 && itnum < iterations)
    denom = derivative(x0);
    if(denom ~= 0)                                                          %check to see denominator doesnt become 0
        itnum = itnum + 1;
        x1 = x0 - polynomial(x0)/denom;
        if(abs(x1-x0) < converge)                                           %if root converges then loop terminates here
            answer = x1;
            errorcode = 0;
            fprintf('converged at %i iterations', itnum);
        else
            x0 = x1;                                                        %go to next iteration
        end
        X_double(itnum) = itnum;
        Y_double(itnum) = x1;
        if(itnum>=2)
            Y_Err(itnum) = abs(Y_double(itnum) - Y_double(itnum-1));
        end
    else
        itnum = itnum + 1;
        errorcode = 2;                                                      %error if denominator is 0
        fprintf('derivative is zero at %f iteration', itnum);
    end
    if(itnum == iterations)
        answer = x1;
        errorcode = 1;                                                      %error if max iterations reached
        fprintf('max iterations over');
    end
end
end