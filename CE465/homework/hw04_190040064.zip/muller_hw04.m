function[answer] = muller_hw04(func, point1, point2, point3, iterations)                    %Defining function for Mullers Method

converge = 2.22e-14;                                                                        %Convergence criterion given in the question
x = double.empty(iterations+3, 0);
x(1) = point1;
x(2) = point2;
x(3) = point3;
itnum = 0;
answer = 0;
errorcode = -1;

f = func;                                                                                   %Defining functions and functionals used in calculations
functional_2 = @(x2,x1) (f(x1)-f(x2))/(x1-x2);
functional_3 = @(x2,x1,x0) (functional_2(x1,x0) - functional_2(x2,x1))/(x0-x2);

i = 4;
for i = 4:iterations+3
    w = functional_2(x(i-1), x(i-2)) + functional_2(x(i-1), x(i-3)) - functional_2(x(i-2), x(i-3));     %Directly using relation between W and functionals
    denom1 = w + sqrt(w.^2 - 4*f(x(i-1))*functional_3(x(i-1), x(i-2), x(i-3)));                         %Selecting between greater magnitude denominator to prevent error due to small number division.
    denom2 = w - sqrt(w.^2 - 4*f(x(i-1))*functional_3(x(i-1), x(i-2), x(i-3)));
    Denom = max(denom1,denom2);
    x(i) = x(i-1) - 2*f(x(i-1))/Denom;                                                                  %Finding next point in the method
    
    Err(i) = abs(x(i) - x(i-1));
    if(abs(x(i) - x(i-1)) < converge)
        errorcode = 0;
        fprintf("converged at %i iteration ", i-3);
        break
    end
end
answer = x(i);

figure(5);
plot(4:i, Err(4:i));
grid on;
xlabel('Number of Iterations');
ylabel('Error convergence');
title("Mullers Method");

