%
% -------------------
% This is a solution to the Homework no. 4 for  CE 465, Numerical Methods in Civil Engineering 
% course at IIT Bombay instructed by Prof. Ravi Sinha (Spring 2020-21)
% 
% in the present file we have to evaluate the roots of two functions
% using 2 different methods.
% 
%
%
% Assumptions and Notices: 
%   - Parts A and B are user input
% 
% Author: Naman Chanduka, IIT Bombay
%
%
% -------------------

clear; clc; close all; %used for clearing the workspace

tic; %used for monitoring the runtime of the program

format long; %to accurately see more decimal points

%%
%%%%%%%%  Start of User Input  %%%%%%%%%%%%%%%
%Enter which question part you wish to see
 
questionPart = 'A';                             %Controls the points used for mullers method and initial point for newtons method as user input
point1A = 0;
point2A = 2;
point3A = 4;
NewtonPointA = 7;

questionPart = 'B';
point1B = 0;
point2B = 2;
point3B = 4;
NewtonPointB = 5;


iterationsForMuller = 100;                       %controls the maximum number of iterations allowed in the muller method.

iterationsForNewton = 100;                       %controls the maximum number of iterations allowed in the newton method.

%%%%%%%% End of User Input  %%%%%%%%%%%%%

%% start of program

answer = 0;
X_newton = double.empty(iterationsForNewton+1, 0);
Y_newton = double.empty(iterationsForNewton+1, 0);
Y_RelErr = double.empty(iterationsForNewton+1, 0);

switch questionPart
    
    case 'A'     
        f = @(x) x.^3 - 3*x.^2 + 3*x - 1;
        y = muller_hw04(f, point1A, point2A, point3A, iterationsForMuller);
        disp(y);
        [answer, X_newton, Y_newton, Y_RelErr] = newton_hw04(f, questionPart, NewtonPointA, iterationsForNewton);
        disp(answer);
        Y_newton = abs(Y_newton - answer);
        figure(1);                                                                        %plot for the newton method absolute error.
        semilogy(X_newton, Y_newton);
        grid on;
        xlabel('Number of iterations');
        ylabel('Absolute error (log scale)');
        title('Newton method');
        
        figure(2);                                                                        %plot for the newton method relative error.
        semilogy(X_newton, Y_RelErr);
        grid on;
        xlabel('Number of iterations');
        ylabel('Relative error (log scale)');
        title('Newton method');
        
    case 'B'
        f = @(x) x.^4 - 3*x.^3 + 20*x.^2 + 44*x + 54;    
        y = muller_hw04(f, point1B, point2B, point3B, iterationsForMuller);
        disp(y);
        [answer, X_newton, Y_newton, Y_RelErr] = newton_hw04(f, questionPart, NewtonPointB, iterationsForNewton);
        disp(answer);
        Y_newton = abs(Y_newton - answer);
        figure(3);                                                                          %plot for the newton method absolute error.
        semilogy(X_newton, Y_newton);
        grid on;
        xlabel('Number of iterations');
        ylabel('Absolute error (log scale)');
        title('Newton method');
        
        figure(4);    
        semilogy(X_newton, Y_RelErr);                                                               %plot for the newton method relative error.
        grid on;
        xlabel('Number of iterations');
        ylabel('Relative error (log scale)');
        title('Newton method');
end

toc;

%%%%%%%%%%%%%%%%%% End of Program %%%%%%%%%%%%%%%%%%%%%%