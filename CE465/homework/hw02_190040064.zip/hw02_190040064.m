%
% -------------------
% This is a solution to the Homework no. 2 for  CE 465, Numerical Methods in Civil Engineering 
% course at IIT Bombay instructed by Prof. Ravi Sinha (Spring 2020-21)
% 
% in the present file we have to evaluate the function f(x) = x^3 - 3x^2 + 3x - 1
%
% Assumptions and Notices: 
%   - Options A and B are user input
% 
% Author: Naman Chanduka, IIT Bombay
%
%
% -------------------

clear; clc; close all; %used for clearing the workspace

tic; %used for monitoring the runtime of the program

format long; %to accurately see more decimal points

%%
%%%%%%%%  Start of User Input  %%%%%%%%%%%%%%%
%Enter which question part you wish to see scatter plot of.

questionPart = 'a'; 
%questionPart = 'b';

%function used as directed in the question
%%%%%%%% End of User Input  %%%%%%%%%%%%%

%% start of program

switch questionPart
    case 'a'
        x = single([0:0.01:2]);                   % x is taken as directed in part 'a' of the question
        y = x.^3 - 3*x.^2 + 3*x - 1;              % y is f(x). '.^' is used as x is a vector and we need individual squares/cubes of each point
        figure(1)                                 % creates graph for the scatter plot
        scatter(x,y,5);                           % creates scatter plot for part a of the question
        
        
    case 'b'
        x = single([0.9998:5e-06:1.0002]);        % x is taken as directed in part 'b' of the question
        y = x.^3 - 3*x.^2 + 3*x - 1;              % y is f(x). '.^' is used as x is a vector and we need individual squares/cubes of each point
        figure(2)                                 % creates graph for the scatter plot
        scatter(x,y,5);                           % creates scatter plot for part b of the question
end

toc;

%%%%%%%%%%%%%%%%%% End of Program %%%%%%%%%%%%%%%%%%%%%%