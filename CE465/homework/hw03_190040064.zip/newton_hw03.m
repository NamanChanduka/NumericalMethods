function [answer, X_double, Y_double] = newton_hw03(x0, iterations)         %Defining Newton Function
    function y = polynomial(x)                                              %Defining polynomial function
        y = x.^6 - 15*x + 3;
    end
    function y = derivative(x)                                   
        %Defining derivative function
        y = 6*x.^5 - 15;
    end
X_double = double.empty(iterations+1, 0);                                   %initializing array that will be required for plotting
Y_double = double.empty(iterations+1, 0);                                   %initializing array for calculating relative error
errorcode = -1;                                                             %initialize errorcode to find irregularities during runtime
itnum = 0;                                                                  %initialize iteration variable
answer = 0;
converge = 2.22e-14;                                                        %convergence criterion according to question
while(errorcode == -1 && itnum < iterations)
    denom = derivative(x0);
    if(denom ~= 0)                                                          %check to see denominator doesnt become 0
        itnum = itnum + 1;
        x1 = x0 - polynomial(x0)/denom;
        if(abs(x1-x0) < converge)                                           %if root converges then loop terminates here
            answer = x1;
            errorcode = 0;
            fprintf('converged at %i iterations', itnum);
        else
            x0 = x1;                                                        %go to next iteration
        end
        X_double(itnum) = itnum;
        Y_double(itnum) = x1;
    else
        itnum = itnum + 1;
        errorcode = 2;                                                      %error if denominator is 0
        fprintf('derivative is zero at %f iteration', itnum);
    end
    if(itnum == iterations)
        answer = x1;
        errorcode = 1;                                                      %error if max iterations reached
        fprintf('max iterations over');
    end
end
end