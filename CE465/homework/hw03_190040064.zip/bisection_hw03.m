function [answer, X_double, Y_double] = bisection_hw03(start, finish, iterations)           %Defining bisection function
    function y = polynomial(x)                                                              %Defining Polynomial function
        y = x.^6 - 15*x + 3;
    end
X_double = double.empty(iterations+1, 0);                                                   %array of number of iterations used in plot
Y_double = double.empty(iterations+1, 0);                                                   %midpoint after every method to check for relative error
errorcode = 0;                                                                              %to check for errors and irregularities while executing the function
itnum = 0;                                                                                  %initializing iteration variable
answer = 0;                                                                                 %initialize answer variable
converge = 2.22e-14;                                                                        %convergence criterion as mentioned in the question
while(errorcode == 0 && itnum < iterations)
    if(polynomial(start)*polynomial(finish) <= 0 )                                          %check if entered start and finish points are correct
        if(polynomial(start)*polynomial((start+finish)/2) <= 0)                             %checking at mid point to see where root lies
            finish = (start+finish)/2;
        else
            start = (start+finish)/2;
        end
        errorcode = 0;
        X_double(itnum+1) = itnum + 1;
        Y_double(itnum+1) = (start+finish)/2;
        itnum = itnum + 1;
    else
        errorcode = 1;                                                                      %assigning errorcode 1 which shows that entered start and finish points arent necessarily correct
        itnum = itnum + 1;
        fprintf("error occured, probably wrong points entered, please check. failed at %i iteration", itnum);
    end
    if(itnum == iterations)                                                                 %max iterations reached, then loop terminates here
        answer = (start+finish)/2;
        fprintf("finished all iterations");
    end 
    if(finish-start <= converge)                                                            %root converges according to convergence criterion then loop terminates here
        answer = (start+finish)/2;
        fprintf("converged at %i iteration", itnum);
        break;
    end
end
end