%
% -------------------
% This is a solution to the Homework no. 3 for  CE 465, Numerical Methods in Civil Engineering 
% course at IIT Bombay instructed by Prof. Ravi Sinha (Spring 2020-21)
% 
% in the present file we have to evaluate the roots of the function
% f(x) = x^6 - 15x + 3 = 0 using 2 different methods.
% 
%
%
% Assumptions and Notices: 
%   - Parts A and B are user input
% 
% Author: Naman Chanduka, IIT Bombay
%
%
% -------------------

clear; clc; close all; %used for clearing the workspace

tic; %used for monitoring the runtime of the program

format long; %to accurately see more decimal points

%%
%%%%%%%%  Start of User Input  %%%%%%%%%%%%%%%
%Enter which question part you wish to see
 
questionPart = 'Bisection Method'; 
%questionPart = 'Newtons Method';


iterationsForBisection = 50;                    %controls the maximum number of iterations allowed in the bisection method.

iterationsForNewton = 10;                       %controls the maximum number of iterations allowed in the newton method.

%%%%%%%% End of User Input  %%%%%%%%%%%%%

%% start of program

switch questionPart
    
%% Bisection Method
    case 'Bisection Method'     %Check function file to see more about the function.
        answer1b = 0;                                                                     %initializing these variables and arrays which are required for plots.
        answer2b = 0;
        X_plot1b = double.empty(iterationsForBisection+1, 0);
        Y_plot1b = double.empty(iterationsForBisection+1, 0);
        X_plot2b = double.empty(iterationsForBisection+1, 0);
        Y_plot2b = double.empty(iterationsForBisection+1, 0);
        
        [answer1b, X_plot1b, Y_plot1b] = bisection_hw03(0, 1, iterationsForBisection);    %calling bisection function for the first root between 0 and 1
        disp(answer1b);
        Y_plot1b = abs(Y_plot1b - 0.2000042672129);
        figure(1);                                                                        %plot for the bisection method of first root absolute error.
        semilogy(X_plot1b, Y_plot1b);
        grid on;
        xlabel('Number of iterations');
        ylabel('Absolute error (log scale)');
        title('Bisection method first root');
        
        figure(2);                                                                        %plot for the bisection method of first root relative error.
        semilogy(X_plot1b, Y_plot1b./(0.2000042672129));
        grid on;
        xlabel('Number of iterations');
        ylabel('Relative error (log scale)');
        title('Bisection method first root');
        
        [answer2b, X_plot2b, Y_plot2b] = bisection_hw03(1, 2, iterationsForBisection);    %calling bisection function for the second root between 1 and 2
        disp(answer2b);
        Y_plot2b = abs(Y_plot2b - 1.675629977458);
        figure(3);                                                                        % plot for the bisection method of second root absolute error.
        semilogy(X_plot2b, Y_plot2b);
        grid on;
        xlabel('Number of iterations');
        ylabel('Absolute error (log scale)');
        title('Bisection method second root');
        
        figure(4);                                                                        % plot for the bisection method of second root relative error.
        semilogy(X_plot2b, Y_plot2b./(1.675629977458));
        grid on;
        xlabel('Number of iterations');
        ylabel('Relative error (log scale)');
        title('Bisection method second root');
        
%% Newtons Method
    case 'Newtons Method'
        answer1n = 0;
        answer2n = 0;
        X_plot1n = double.empty(iterationsForNewton+1, 0);
        Y_plot1n = double.empty(iterationsForNewton+1, 0);
        X_plot2n = double.empty(iterationsForNewton+1, 0);
        Y_plot2n = double.empty(iterationsForNewton+1, 0);
        
        [answer1n, X_plot1n, Y_plot1n] = newton_hw03(1, iterationsForNewton);    %calling newton function for the first root between 0 and 1
        disp(answer1n);
        Y_plot1n = abs(Y_plot1n - 0.2000042672129);
        figure(5);                                                                        %plot for the newton method of first root absolute error.
        semilogy(X_plot1n, Y_plot1n);
        grid on;
        xlabel('Number of iterations');
        ylabel('Absolute error (log scale)');
        title('Newton method first root');
        
        figure(6);                                                                        %plot for the newton method of first root relative error.
        semilogy(X_plot1n, Y_plot1n./(0.2000042672129));
        grid on;
        xlabel('Number of iterations');
        ylabel('Relative error (log scale)');
        title('Newton method first root');
        
        [answer2n, X_plot2n, Y_plot2n] = newton_hw03(2, iterationsForNewton);    %calling newton function for the second root between 1 and 2
        disp(answer2n);
        Y_plot2n = abs(Y_plot2n - 1.675629977458);
        figure(7);                                                                        % plot for the newton method of second root absolute error.
        semilogy(X_plot2n, Y_plot2n);
        grid on;
        xlabel('Number of iterations');
        ylabel('Absolute error (log scale)');
        title('Newton method second root');
        
        figure(8);                                                                        % plot for the newton method of second root relative error.
        semilogy(X_plot2n, Y_plot2n./(1.675629977458));
        grid on;
        xlabel('Number of iterations');
        ylabel('Relative error (log scale)');
        title('Newton method second root');
end

toc;

%%%%%%%%%%%%%%%%%% End of Program %%%%%%%%%%%%%%%%%%%%%%