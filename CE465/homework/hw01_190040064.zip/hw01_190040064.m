clear; clc; close all;
eps = 1;
eps = 0.5*eps;
epsSingle = single(eps);
epsp1 = 1 + eps;
epsp1Single = single(1 + epsSingle);
while(epsp1 > 1)
    eps = 0.5*eps;
    epsp1 = 1 + eps;
end
while(epsp1Single > 1)
    epsSingle = single(0.5*epsSingle);
    epsp1Single = single(1 + epsSingle);
end
precisionDouble = eps*2;
precisionSingle = epsSingle*2;
disp(eps); 
disp(epsSingle);
disp(precisionDouble);   %because we get eps value within a factor of 0.5 so to get precision, we multiply by 2%
disp(precisionSingle);
whos;